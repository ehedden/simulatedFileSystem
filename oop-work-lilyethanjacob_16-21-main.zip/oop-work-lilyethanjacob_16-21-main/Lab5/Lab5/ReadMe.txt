Lab 5 - Jacob Freund, Ethan Hedden, Lily Goldberg

Tests Ran:
created new image and txt files (touch)
wrote to the files, both with and without saving and flag
displayed files, with and without -d flag
used ls to see what files are contained, with and without flag
removed files to test remove command, then used ls to see that the file was removed
renamed existing files to test rename command


Errors/Bugs encountered:
Error with cat command with images, incorrect size error (fixed)
Issue with ds command, fixed with changes to basic diplay visitor (fixed)
Issue with -p flag on touch command 


Extra Credit was completed for GrepCommand! - tested grep with different text files and string inputs