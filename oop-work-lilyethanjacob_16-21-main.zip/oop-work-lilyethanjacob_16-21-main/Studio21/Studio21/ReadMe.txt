Studio 21 ReadMe.txt 

2.  A virutal destructor is important since what ever class that inherits from AbstarctCommand might have 
different member variables - meaning the destructor would be unique for each class.

3.  A command prompt does not know what is interacting with in its creation.  This means we can 
alter some code - like an image text file, or how the commands are executed - whith out changing a lot with in the base file itself.
For this project it is not that big of a deal, but for larger projects with more people, dependency injection means alot for 
modularity.

4.  For testing, checked if q worked, and if it could detect an inappropriate parameter (no files, bad file, bad usage).  
To test that the file was created correctly, I tried to open the created file (note it is just a blank text file so it was detected
with just a white line).  The TouchCommand works as expected!