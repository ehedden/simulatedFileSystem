// Studio21.cpp : This file contains the 'main' function. Program execution begins and ends there.
//



#include "../../SharedCode/TextFile.h"
#include "../../SharedCode/ImageFile.h"
#include "../..//SharedCode/SimpleFileFactory.h"
#include "../../SharedCode/SimpleFileSystem.h"
#include "../../SharedCode/BasicDisplayVisitor.h"
#include "../../SharedCode/MetadataDisplayVisitor.h"
#include "../../SharedCode/PasswordProxy.h"
#include "../../SharedCode/TouchCommand.h"
#include "../../SharedCode/CommandPrompt.h"
#include "../../SharedCode/CommandTest.cpp"

#include <iostream>
#include <sstream>


using namespace std;



int main()
{
	AbstractFileSystem* sfs = new SimpleFileSystem();
	AbstractFileFactory* sff = new SimpleFileFactory();
	TouchCommand* tcmd = new TouchCommand(sfs, sff);
	CommandPrompt* cmdPrompt = new CommandPrompt();
	cmdPrompt->setFileSystem(sfs);
	cmdPrompt->setFileFactory(sff);
	cmdPrompt->addCommand("test", tcmd);
	cmdPrompt->run();
	sfs->openFile("test");

	return 0;
	/*  //for debugging
	// SET UP FILE SYSTEM
	AbstractFileSystem* sfs = new SimpleFileSystem();
	AbstractFileFactory* sff = new SimpleFileFactory();
	CommandPrompt* cp = new CommandPrompt;
	cp->setFileSystem(sfs);
	cp->setFileFactory(sff);
	// ADD COMMAND
	CommandTest* ct = new CommandTest(sfs);
	string commandname = "test";
	cp->addCommand(commandname, ct);
	// REDIRECT COUT STREAM
	streambuf* backup_out;
	backup_out = cout.rdbuf();
	stringstream ss_out;
	cout.rdbuf(ss_out.rdbuf());
	// REDIRECT CIN STREAM
	streambuf* backup_in;
	backup_in = cin.rdbuf();
	stringstream ss_in;
	cin.rdbuf(ss_in.rdbuf());
	// MIMIC USER INPUT
	string input = "test foo moo\nq\n";
	ss_in << input;
	int response = cp->run();
	string word;
	std::vector<string> printedWords;
	while (ss_out >> word) {
		printedWords.push_back(word);

	}
	// EXPECTATION -- ALL PARAMETERS SHOULD BE PRINTED TO COUT   //so this is execute more inputs
	std::vector<string>::iterator it1;
	string expectedOutput = "foo:moo";
	it1 = std::find(printedWords.begin(), printedWords.end(), expectedOutput);
	bool notEqual1 = it1 == printedWords.end();

	// ASSIGN COUT BACK TO STDOUT
	cout.rdbuf(backup_out);
	// ASSIGN CIN BACK TO STDIN
	cin.rdbuf(backup_in);
	cout << "now printing out what is in my vector" << endl;
	for (vector<string>::iterator t = printedWords.begin(); t != printedWords.end(); ++t)
	{
		cout << *t << endl;
	}
	cout << "want false but have: " << notEqual1 << endl;
	*/
	

	
}

