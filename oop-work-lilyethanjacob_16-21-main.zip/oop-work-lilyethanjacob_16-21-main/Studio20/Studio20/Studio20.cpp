// Studio20.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "H:\repositories\oop-work-lilyethanjacob_16-21\SharedCode\TextFile.h"
#include "H:\repositories\oop-work-lilyethanjacob_16-21\SharedCode\PasswordProxy.h"
#include <vector>

using namespace std;

int main()
{
	vector<char> file; 

	file.push_back('h');
	file.push_back('e');
	file.push_back('l');
	file.push_back('l');
	file.push_back('o');
	TextFile* myFile = new TextFile("name");
	myFile->write(file);
	PasswordProxy p(myFile, "password");
	
	vector<char> word;
	word.push_back('h');
	word.push_back('i');

	vector<char> toPrint = p.read();
	for(char c : toPrint) {
		cout << c;
	}
	p.append(word);
	vector<char> toPrint2 = p.read();
	for(char c : toPrint2) {
		cout << c;
	}

	return 0;
}

