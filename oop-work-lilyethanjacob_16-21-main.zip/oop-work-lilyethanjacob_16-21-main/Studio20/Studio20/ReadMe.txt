Studio 20 ReadMe.txt
1. Ethan Hedden, Jacob Freund, Lily Goldberg

2. The pointer to the file must be destroyed because PasswordProxy takes in a pointer to an AbstractFile.  AbstractFile can be
destroyed independelty, so if we don't also destroy the pointer itself, we will have a dangling pointer.

4. 