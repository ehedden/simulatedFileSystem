studio 19 answers here
1. Jacob Freund, Ethan Hedden, Lily Goldberg

2. We tested by creating a TextFile, then changing its contents using write, then reading from the file
and printing it to the terminal.

3. Each ConcreteElement implements its own accept method which gives the visitors access to the concrete file types. 
When a visitor requests to visit a file, the file must accept it, providing access to the visitor.

4. Delegation is when you use another object to do some instruction, while giving a reference to the object sending the instruction
such that the object recieving the instruction can use the sender's member functions.