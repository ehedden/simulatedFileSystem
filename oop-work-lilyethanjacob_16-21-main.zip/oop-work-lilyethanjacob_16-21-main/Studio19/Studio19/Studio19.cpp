// Studio19.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <string>
#include "..\..\SharedCode\TextFile.h"
#include "..\..\SharedCode\BasicDisplayVisitor.h"

using namespace std;

int main()
{
	
	TextFile * myFile = new TextFile("hello");
	BasicDisplayVisitor * bds = new BasicDisplayVisitor;

	vector<char> word;
	word.push_back('h');
	word.push_back('i');

	(*myFile).write(word);
	vector<char> test = (*myFile).read();

	std::vector<char>::iterator it = test.begin();
	while (it != test.end()) {
		std::cout << *it;
		it++;
	}
	return 0;
}
