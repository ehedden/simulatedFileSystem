// Studio17.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

using namespace std;


int main()
{
	return 0;
}

