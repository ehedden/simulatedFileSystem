Answer the studio 17 questions here.
1. Lily Goldberg, Jacob Freund, Ethan Hedden

2. 

3.  Interfaces are useful since we can create more modular code where a specific type can change at compile time.