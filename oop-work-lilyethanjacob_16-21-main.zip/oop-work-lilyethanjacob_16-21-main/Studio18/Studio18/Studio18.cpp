// Studio18.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include "../../SharedCode/SimpleFileSystem.h"
#include "../../SharedCode/SimpleFileFactory.h"
using namespace std;

int main()
{
	AbstractFileSystem* afs = new SimpleFileSystem();
	AbstractFileFactory * aff = new SimpleFileFactory();
	(*afs).addFile("textFile.txt", (*aff).createFile("textFile.txt"));
	return 0;
}
