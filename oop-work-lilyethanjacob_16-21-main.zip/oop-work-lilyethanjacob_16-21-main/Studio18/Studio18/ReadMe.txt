studio 18 answers here
1. Lily Goldberg, Ethan Hedden, Jacob Freund

2. Very similar to today's studio - simplifies the main method and what the user actually has to do to use
our objects.

3.  We can control what files can be created depending on the file system we are using.
Also by using a FileFactory, we remove the File System's need to create the objects
