// Studio16.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "..\..\\SharedCode\TextFile.h"
#include <iostream>
#include <string>
using namespace std;


int main(){
	string basic = "Ethan Lily Jacob";
	vector<char> v;
	copy(basic.begin(), basic.end(), back_inserter(v));
	TextFile s("mainfile");
	AbstractFile * t = &s;
	cout << t->getName() << endl;
	t->write(v);
	t->read();
	return 0;
}


