Answer studio 16 questions here

1.  Lily Goldberg, Ethan Hedden, Jacob Freund

2.  An interface has pure virtual functions that are intended to be implemented later, in derivived classes.

3.  a.  Interface Inheritance   b.  The member variables should be private.

4.  The function behaved as expected, we could write and read from text file.  Also we could append as needed.

5.  I just made it a pointer to an abstract class.  Thus t could point to any of its derived classes.  
(i.e. T is a pointer to objects that contain "these methods")
